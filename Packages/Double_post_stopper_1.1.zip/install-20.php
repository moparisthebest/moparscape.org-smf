<?php
global $smcFunc;
$smcFunc['db_insert'](
	'ignore',
	'{db_prefix}settings',
	array('variable' => 'string'),
	array('doublePostThold'));
?>