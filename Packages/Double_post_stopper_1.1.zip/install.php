<?php
// This way to little file Makes the DB changes...
global $db_prefix;
db_query("INSERT IGNORE INTO {$db_prefix}settings (variable) VALUES ('doublePostThold')", __FILE__, __LINE__);
?>