[b]Author[/b] : Dragooon
[b]Version[/b] : 1.1
[b]Name[/b] : Double Post Stopper
[b]Tested with[/b] : 1.1.4, 2.0 Beta 3 public
[hr]

This Mods enables you to stop users from double posting and bumping/spamming the topic. This mod adds a setting in Admin > Posts and Topics > Topic Settings in which you can define the duration
of time, from before a User cannot post a continues second reply.
Example He/She posted a reply at 2 PM, 18 Nov, and you set the threshhold to be 1 day. He cannot post a reply until he next day's 2 PM unless someone else has posted.
This can be used to prevent quick bumping of topics.
It also adds a permission(Which can be altered via Admin > Permissions) which, if checked, the double posting check is not applied on the users of that member group.
Should work on every theme. If you are using a language other than "English", in your Modifications.*language".php(Found in /Themes/default/langiages) before "?>" Add
[code]
// Double Post stopper strings
$txt['double_post_attempt'] = 'Sorry, but you are not allowed to double post. Please go back and edit your previous post.';
$txt['permissionname_doublePost'] = 'Allow them to Double post';
$txt['permissionhelp_doublePost'] = 'By Enabling this You will allow them to double post.';
$txt['doublePostAdmin_main'] = 'Time before the user is not allowed to double post';
$txt['doublePostHelp'] = 'Time(in Days) before double posting is considered as a bump attempt. A user is not allowed to post a continous second reply within the given time threshhold.';
$txt['doublePostAdmin_sub'] = 'Is set as in Days. Click on the "?" if you want more information. Leave Blank to prevent double posting always';

[/code]
[hr]
[b]Languages[/b]
[list]
[li]English by Dragooon[/li]
[li]Italian by Darknico[/li]
[li]Turkish by ??l?az[/li]
[li]French by [SAP]Francis[/li]
[/list]
[hr]
[size=11pt][b]Changelog[/b][/size]

[b]Version 1.0[/b]
[list]
[li]Initial Release[/li]
[/list]

[b]Version 1.0.1[/b]
[list]
[li]Added Italian Language given By Darknico[/li]
[/list]

[b]Version 1.1[/b]
[list]
[li]Improved code[/li]
[li]Added support for SMF 2 Beta 3 public[/li]
[li]Added turkish language[/li]
[li]Added french language[/li]
[/list]
[hr]

Thank you for using this mod! :)