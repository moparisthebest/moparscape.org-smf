[center][color=green][size=2em]Remove Images from quotes[/size][/color][/center]

This modification is based on the [TIP] by Heavyccasey on the support forum.

This mod removes images from quoted text and leaves a link to the image. 
Clicking the link restores the removed image.

Version History:
1.6 Updated for 2.0.1+
1.5 Checked with 2.0
1.4 Final installer bug fix.
1.3 Minor bug fix on installer.
1.2 Included Skip for Language support and corrected code for xHtml validation.
1.1 Included reference to text in modifications list and Skip on error for language english_british.
1.0 Mod tested and working on two forums.

Please use the support link if required.

Regards

Chas Large
November 2011
